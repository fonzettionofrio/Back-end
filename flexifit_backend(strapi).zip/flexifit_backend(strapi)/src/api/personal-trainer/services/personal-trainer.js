'use strict';

/**
 * personal-trainer service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::personal-trainer.personal-trainer');
