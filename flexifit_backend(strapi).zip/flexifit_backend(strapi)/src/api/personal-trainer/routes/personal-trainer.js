'use strict';

/**
 * personal-trainer router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::personal-trainer.personal-trainer');
