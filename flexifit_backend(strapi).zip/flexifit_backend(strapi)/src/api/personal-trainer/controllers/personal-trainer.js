'use strict';

/**
 * personal-trainer controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::personal-trainer.personal-trainer');
