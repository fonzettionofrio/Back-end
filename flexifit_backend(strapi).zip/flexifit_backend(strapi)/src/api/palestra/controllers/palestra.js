'use strict';

/**
 * palestra controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::palestra.palestra');
