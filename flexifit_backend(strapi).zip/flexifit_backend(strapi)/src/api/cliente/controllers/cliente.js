'use strict';

/**
 * cliente controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::cliente.cliente');
