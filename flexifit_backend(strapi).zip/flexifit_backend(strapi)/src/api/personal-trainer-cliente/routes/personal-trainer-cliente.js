'use strict';

/**
 * personal-trainer-cliente router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::personal-trainer-cliente.personal-trainer-cliente');
