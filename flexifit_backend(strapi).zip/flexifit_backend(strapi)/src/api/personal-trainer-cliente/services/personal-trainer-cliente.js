'use strict';

/**
 * personal-trainer-cliente service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::personal-trainer-cliente.personal-trainer-cliente');
