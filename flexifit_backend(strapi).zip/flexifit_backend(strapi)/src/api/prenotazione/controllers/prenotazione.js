'use strict';

/**
 * prenotazione controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::prenotazione.prenotazione');
