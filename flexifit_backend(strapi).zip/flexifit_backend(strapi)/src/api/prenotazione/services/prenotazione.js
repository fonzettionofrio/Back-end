'use strict';

/**
 * prenotazione service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::prenotazione.prenotazione');
