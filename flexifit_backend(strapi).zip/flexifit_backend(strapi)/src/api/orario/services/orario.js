'use strict';

/**
 * orario service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::orario.orario');
